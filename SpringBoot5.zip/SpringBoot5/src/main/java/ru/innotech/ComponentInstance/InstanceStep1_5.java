package ru.innotech.ComponentInstance;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import ru.innotech.Dto.Enum.AccountTypes;
import ru.innotech.Dto.CorporateSettlementAccountDto;
import ru.innotech.Dto.ResponseAccountIntDto;
import ru.innotech.Dto.CorporateSettlementInstanceDto;
import ru.innotech.Dto.ResponseInstanceDto;
import ru.innotech.Service.AccountService;
import ru.innotech.Service.InstanceServiceable;

@Component
@Order(5)
@Qualifier("Creating")
public class InstanceStep1_5 implements InstanceServiceable {
    @Autowired
    AccountService accountService;
    @Override
    public void process(CorporateSettlementInstanceDto reqInstDto, ResponseInstanceDto respInstDto) throws Exception {
        System.out.println("InstanceStep1_5:Добавить в таблицу ПР (tpp_product_registry) заполненные строки"+
                "см. задачу на создание продуктового регистра по методу corporate-settlement-account/create");
        CorporateSettlementAccountDto reqAcc = new CorporateSettlementAccountDto(
                Long.parseLong(respInstDto.getInstanceId()),
                reqInstDto.getRegisterType(),
                String.valueOf(AccountTypes.CLIENT),
                reqInstDto.getIsoCurrencyCode(),
                reqInstDto.getBranchCode(),
                reqInstDto.getUrgencyCode(),
                reqInstDto.getMdmCode(),
                null,
                null,
                null,
                null);

        ResponseAccountIntDto accountResponse = accountService.process(reqAcc);
    }
}
