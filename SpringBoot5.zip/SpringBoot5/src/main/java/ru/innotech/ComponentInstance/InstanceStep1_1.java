package ru.innotech.ComponentInstance;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import ru.innotech.CustomErrorHandler.InvalidDataInRequest;
import ru.innotech.Entity.TppProduct;
import ru.innotech.Dto.CorporateSettlementInstanceDto;
import ru.innotech.Dto.ResponseInstanceDto;
import ru.innotech.Repository.TppProductRepo;
import ru.innotech.Service.InstanceServiceable;

import java.util.List;

@Component
@Order(1)
@Qualifier("Creating")
public class InstanceStep1_1  implements InstanceServiceable {
    @Autowired
    TppProductRepo tppProductRepo;

    @Override
    public void process(CorporateSettlementInstanceDto reqInstDto, ResponseInstanceDto respInstDto) {
        System.out.println("InstanceStep1_1 -Проверка таблицы ЭП (tpp_product) на дубли. ");
        List<TppProduct> lp =  tppProductRepo.findFirstByNumber(reqInstDto.getContractNumber());
        if (!lp.isEmpty()) {
            throw new InvalidDataInRequest("Параметр ContractNumber № договора "+reqInstDto.getContractNumber()+" уже существует для ЭП с ИД " + lp.get(0).getId());
        }
    }
}
