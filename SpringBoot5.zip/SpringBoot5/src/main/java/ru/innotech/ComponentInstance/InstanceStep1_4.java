package ru.innotech.ComponentInstance;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import ru.innotech.Entity.Agreement;
import ru.innotech.Entity.TppProduct;
import ru.innotech.Dto.CorporateSettlementInstanceDto;
import ru.innotech.Dto.ResponseInstanceDto;
import ru.innotech.Repository.TppProductRepo;
import ru.innotech.Service.InstanceServiceable;

import java.sql.Timestamp;
import java.util.ArrayList;

@Component
@Order(4)
@Qualifier("Creating")
public class InstanceStep1_4 implements InstanceServiceable {
    @Autowired
    TppProductRepo tppProductRepo;

    @Override
    public void process(CorporateSettlementInstanceDto reqInstDto, ResponseInstanceDto respInstDto) {
        System.out.println("InstanceStep1_4- Сформировать/Запомнить новый ИД ЭП tpp_product.id");
        TppProduct tp = new TppProduct(null                         //id
                , new ArrayList<Agreement>()                        //agreementSet
                , Long.parseLong(respInstDto.getRegisterId().get(0))   //product_code_id
                , Long.parseLong(reqInstDto.getMdmCode())             //client_id
                , reqInstDto.getProductType()                          //type
                , reqInstDto.getContractNumber()                       //number
                , reqInstDto.getPriority().longValue()                 //priority
                , new Timestamp(reqInstDto.getContractDate().getTime())//date_of_conclusion
                , null                                              //start_date_time
                , null                                              //end_date_time
                , null                                              //days
                , reqInstDto.getInterestRatePenalty()                  //penalty_rate
                , reqInstDto.getMinimalBalance()                       //nso
                , reqInstDto.getThresholdAmount()                      //threshold_amount
                , null                                              //requisite_type
                , reqInstDto.getRateType()                             //interest_rate_type
                , reqInstDto.getTaxPercentageRate()                    //tax_rate
                , null                                              //reasone_close
                , null                                              // state
        );
        tppProductRepo.save(tp);
        respInstDto.setInstanceId(tp.getId().toString());
    }
}
