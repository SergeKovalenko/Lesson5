package ru.innotech.ComponentInstance;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import ru.innotech.Dto.AgreementDto;
import ru.innotech.Entity.Agreement;
import ru.innotech.Entity.TppProduct;
import ru.innotech.Dto.CorporateSettlementInstanceDto;
import ru.innotech.Dto.ResponseInstanceDto;
import ru.innotech.Repository.AgreementRepo;
import ru.innotech.Repository.TppProductRepo;
import ru.innotech.Service.InstanceServiceable;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Component
@Order(3)
@Qualifier("Checking")
public class InstanceStep2_3 implements InstanceServiceable {
    @Autowired
    AgreementRepo agreementRepo;
    @Autowired
    TppProductRepo tppProductRepo;
    @Override
    public void process(CorporateSettlementInstanceDto reqInstDto, ResponseInstanceDto respInstDto) throws Exception {
        System.out.println("InstanceStep2_3:Добавить строку в таблицу ДС (agreement)");
        Optional<TppProduct> p = tppProductRepo.findById(reqInstDto.getInstanceId().toString());
        List<String> agreementsIdList = new ArrayList<>();
        TppProduct tp = p.get();
        List<AgreementDto> agreementList = reqInstDto.getInstanceArrangement();
        agreementList.forEach(e -> {
            Agreement agr = new Agreement(null, tp,
                    e.getGeneralAgreementId(),
                    e.getSupplementaryAgreementId(),
                    e.getArrangementType(),
                    e.getShedulerJobId(),
                    e.getNumber(),
                    e.getOpeningDate(),
                    e.getClosingDate(),
                    e.getCancelDate(),
                    e.getValidityDuration(),
                    e.getCancellationReason(),
                    e.getStatus(),
                    e.getInterestCalculationDate(),
                    e.getInterestRate(),
                    e.getCoefficient(),
                    e.getCoefficientAction(),
                    e.getMinimumInterestRate(),
                    e.getMinimumInterestRateCoefficient(),
                    e.getMinimumInterestRateCoefficientAction(),
                    e.getMaximalInterestRate(),
                    e.getMaximalInterestRateCoefficient(),
                    e.getMaximalInterestRateCoefficientAction()
            );
            agreementRepo.save(agr);
            agreementsIdList.add(agr.getId().toString());
        });
        respInstDto.setSupplementaryAgreementId(agreementsIdList);
    }
}
