package ru.innotech.ComponentInstance;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import ru.innotech.CustomErrorHandler.NoDataFoundException;
import ru.innotech.Dto.Enum.AccountTypes;
import ru.innotech.Entity.TppRefProductClass;
import ru.innotech.Dto.CorporateSettlementInstanceDto;
import ru.innotech.Dto.ResponseInstanceDto;
import ru.innotech.Repository.TppRefProductClassRepo;
import ru.innotech.Service.InstanceServiceable;

import java.util.ArrayList;
import java.util.List;
@Component
@Order(3)
@Qualifier("Creating")
public class InstanceStep1_3 implements InstanceServiceable {
    @Autowired
    TppRefProductClassRepo tppRefProductClassRepo;
    @Override
    public void process(CorporateSettlementInstanceDto reqInstDto, ResponseInstanceDto respInstDto) {
        System.out.println("InstanceStep1_3- По КодуПродукта найти связные записи в Каталоге Типа регистра, у которых account_type имеет значение  =Клиентский");
         List<TppRefProductClass> lp = tppRefProductClassRepo.findCatalog(reqInstDto.getProductCode(), AccountTypes.CLIENT.getS());
        if (lp.isEmpty()) {
            throw new NoDataFoundException("КодПродукта " + reqInstDto.getProductCode() + " не найдено в Каталоге продуктов tpp_ref_product_class");
        }
        List<String> registryList = new ArrayList<>();
        lp.forEach(e -> registryList.add(e.getInternal_id().toString()));
        respInstDto.setRegisterId(registryList);
    }
}
