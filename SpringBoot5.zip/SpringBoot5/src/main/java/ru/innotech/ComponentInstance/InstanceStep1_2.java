package ru.innotech.ComponentInstance;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import ru.innotech.CustomErrorHandler.InvalidDataInRequest;
import ru.innotech.Entity.Agreement;
import ru.innotech.Dto.CorporateSettlementInstanceDto;
import ru.innotech.Dto.ResponseInstanceDto;
import ru.innotech.Repository.AgreementRepo;
import ru.innotech.Service.InstanceServiceable;

import java.sql.SQLOutput;
import java.util.List;
@Component
@Order(2)
@Qualifier("Creating")
public class InstanceStep1_2 implements InstanceServiceable {
    @Autowired
    AgreementRepo agreementRepo;

    @Override
    public void process(CorporateSettlementInstanceDto reqInstDto, ResponseInstanceDto respInstDto) {
        System.out.println("InstanceStep1_2 - Проверка таблицы ДС (agreement) на дубли");
        reqInstDto.getInstanceArrangement().forEach(x -> {
            List<Agreement> la = agreementRepo.findFirstByNumber(x.getNumber());
            if (!la.isEmpty()) {
                System.out.println("Параметр № Дополнительного соглашения (сделки) Number " + x.getNumber() + " уже существует для ЭП с ИД " + la.get(0).getId());
                throw new InvalidDataInRequest("Параметр № Дополнительного соглашения (сделки) Number " + x.getNumber() + " уже существует для ЭП с ИД " + la.get(0).getId());
            }
        });
    }
}
