package ru.innotech.ComponentInstance;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import ru.innotech.CustomErrorHandler.NoDataFoundException;
import ru.innotech.Entity.TppProduct;
import ru.innotech.Dto.CorporateSettlementInstanceDto;
import ru.innotech.Dto.ResponseInstanceDto;
import ru.innotech.Repository.TppProductRepo;
import ru.innotech.Service.InstanceServiceable;

import java.util.Optional;

@Component
@Order(1)
@Qualifier("Checking")
public class InstanceStep2_1 implements InstanceServiceable {
    @Autowired
    TppProductRepo tppProductRepo;
    @Override
    public void process(CorporateSettlementInstanceDto reqInstDto, ResponseInstanceDto respInstDto) throws Exception {
        System.out.println("InstatnceStep2_1: Проверка таблицы ЭП (tpp_product) на существование ЭП");
        Optional<TppProduct> tp= tppProductRepo.findById(reqInstDto.getInstanceId().toString());
        if(tp.isEmpty()){
            System.out.println("Экземпляр продукта с параметром instanceId "+reqInstDto.getInstanceId()+" не найден.");
            throw new NoDataFoundException("Экземпляр продукта с параметром instanceId "+reqInstDto.getInstanceId()+" не найден.");
        }
        System.out.println("Экземпляр продукта с параметром instanceId "+reqInstDto.getInstanceId()+" найден.");
    }
}
