package ru.innotech.ComponentInstance;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import ru.innotech.CustomErrorHandler.InvalidDataInRequest;
import ru.innotech.Dto.AgreementDto;
import ru.innotech.Entity.Agreement;
import ru.innotech.Dto.CorporateSettlementInstanceDto;
import ru.innotech.Dto.ResponseInstanceDto;
import ru.innotech.Repository.AgreementRepo;
import ru.innotech.Service.InstanceServiceable;

import java.util.List;

@Component
@Order(2)
@Qualifier("Checking")
public class InstanceStep2_2 implements InstanceServiceable {
    @Autowired
    AgreementRepo agreementRepo;

    @Override
    public void process(CorporateSettlementInstanceDto reqInstDto, ResponseInstanceDto respInstDto) throws Exception {
        System.out.println("InstanceStep2_2:Проверка таблицы ДС (agreement) на дубли" +
                "Отобрать записи по условию agreement.number == Request.Body.Arrangement[N].Number\n");
       List<AgreementDto> agreementList = reqInstDto.getInstanceArrangement();
        agreementList.forEach(x -> {
            List<Agreement> a = agreementRepo.findFirstByNumber(x.getNumber());
            if (!a.isEmpty()) {
                throw new InvalidDataInRequest("Параметр № Дополнительного соглашения (сделки) Number " + x.getNumber() + " уже существует для ЭП с ИД " + a.get(0).getId());
            }
        });
    }
}
