package ru.innotech.Dto;

import lombok.Data;
import java.util.List;

@Data
public class AccountPoolDto {
    private final Integer id;
    private final List<AccountDto> accountSet;
    private final String branch_code;
    private final String currency_code;
    private final String mdm_code;
    private final String priority_code;
    private final String registry_type_code;
}
