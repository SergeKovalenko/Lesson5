package ru.innotech.Dto;

import lombok.Data;

@Data
public class AdditionalPropertiesVipDto {
    private String key;
    private String value;
   // private String name;
}
