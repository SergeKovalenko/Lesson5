package ru.innotech.Dto;

import lombok.Data;

import java.sql.Timestamp;

@Data
public class TppRefProductRegisterTypeDto {
    private final Integer internal_id;
    private final String value;
    private final String register_type_name;
    private final String product_class_code;
    private final TppRefProductClassDto tppRefProductClass;
    private final Timestamp register_type_start_date;
    private final Timestamp register_type_end_date;
    private final String account_type;
    private final TppRefAccountTypeDto tppRefAccountType;
}
