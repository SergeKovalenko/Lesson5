package ru.innotech.Dto;

import lombok.Data;

@Data
public class TppRefAccountTypeDto {
    private final Integer internal_id;
    private final String value;
}
