package ru.innotech.Dto;

import lombok.Data;

@Data
public class TppRefProductClassDto {
    private final Integer internal_id;
    private final String value;
    private final String gbi_code;
    private final String gbi_name;
    private final String product_row_code;
    private final String product_row_name;
    private final String subclass_code;
    private final String subclass_name;
}
