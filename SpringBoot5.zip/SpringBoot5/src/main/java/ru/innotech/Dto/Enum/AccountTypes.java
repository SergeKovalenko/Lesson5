package ru.innotech.Dto.Enum;

import lombok.Getter;
import lombok.ToString;

@ToString
@Getter
public enum AccountTypes {
    CLIENT("Клиентский"), BANK("Внутрибанковский");
    String s;
    AccountTypes(String s) {
        this.s = s;
    }
}
