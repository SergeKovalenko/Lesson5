package ru.innotech.Dto;

import lombok.Data;

@Data
public class TppProductRegisterDto {
    private final Integer id;
    private final Long productId;
    private final Long type;
    private final Long account;
    private final String currency_code;
    private final String state;
    private final String account_number;
}
