package ru.innotech.Dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
public class ResponseInstanceDto {
    String instanceId;
    List<String> registerId;
    List<String> supplementaryAgreementId;
}
