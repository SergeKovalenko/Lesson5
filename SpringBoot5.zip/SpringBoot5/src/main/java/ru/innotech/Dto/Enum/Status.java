package ru.innotech.Dto.Enum;

import lombok.ToString;

@ToString
public enum Status {
    CLOSED("0"), OPEN("1"), RESERVED("2"), DELETED("3");
    String s;
    Status(String s) {
        this.s = s;
    }

}
