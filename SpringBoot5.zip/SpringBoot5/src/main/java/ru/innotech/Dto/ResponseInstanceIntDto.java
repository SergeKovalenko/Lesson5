package ru.innotech.Dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ResponseInstanceIntDto {
    ResponseInstanceDto data;
}
