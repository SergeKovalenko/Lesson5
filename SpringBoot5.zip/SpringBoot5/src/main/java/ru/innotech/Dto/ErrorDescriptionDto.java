package ru.innotech.Dto;

import lombok.Data;

@Data
public class ErrorDescriptionDto {
    private String errnum;
    private String errdescription;
    private String stacktrace;

    public ErrorDescriptionDto(String errnum, String errdescription, String stacktrace) {
        this.errnum = errnum;
        this.errdescription = errdescription;
        this.stacktrace = stacktrace;
    }
}
