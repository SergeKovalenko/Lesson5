package ru.innotech.Dto;

import lombok.Data;

@Data
public class AccountDto {
    private final Long id;
    private final String account_number;
}
