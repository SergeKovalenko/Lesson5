package ru.innotech.Service;

import ru.innotech.Dto.CorporateSettlementInstanceDto;
import ru.innotech.Dto.ResponseInstanceDto;

public interface InstanceServiceable {
    void process(CorporateSettlementInstanceDto reqInstDto, ResponseInstanceDto respInstDto) throws Exception;
}
