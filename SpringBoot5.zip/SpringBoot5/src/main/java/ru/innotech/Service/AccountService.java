package ru.innotech.Service;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.innotech.Dto.CorporateSettlementAccountDto;
import ru.innotech.Dto.ResponseAccountDto;
import ru.innotech.Dto.ResponseAccountIntDto;

import java.util.List;

@Service
public class AccountService {
    @Autowired
    public List<AccountServiceable> accountServiceableList;
    @Transactional
    public ResponseAccountIntDto process(CorporateSettlementAccountDto reqAcc) throws Exception {
        ResponseAccountDto rd = new ResponseAccountDto("");

        for (AccountServiceable pr : accountServiceableList) {
            pr.process(reqAcc, rd);
        }
        ResponseAccountIntDto accountResponse = new ResponseAccountIntDto(rd);
        return accountResponse;
    }
}
