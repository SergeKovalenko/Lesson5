package ru.innotech.Service;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import ru.innotech.Dto.CorporateSettlementInstanceDto;
import ru.innotech.Dto.ResponseInstanceDto;
import ru.innotech.Dto.ResponseInstanceIntDto;

import java.util.ArrayList;
import java.util.List;

@Service
public class InstanceService {
    @Autowired
    @Qualifier("Creating")
    List<InstanceServiceable> instanceServiceableList;
    @Autowired
    @Qualifier("Checking")
    List<InstanceServiceable> instanceServiceableListExist;
    @Transactional
    public ResponseInstanceIntDto process(CorporateSettlementInstanceDto reqInstDto) throws Exception {
        ResponseInstanceDto ri = new ResponseInstanceDto("", new ArrayList<>(), new ArrayList<>());
        for (InstanceServiceable pr : instanceServiceableList) {
            pr.process(reqInstDto, ri);
        }
        for (InstanceServiceable pr : instanceServiceableListExist) {
            pr.process(reqInstDto, ri);
        }
        ResponseInstanceIntDto respInstDto = new ResponseInstanceIntDto(ri);
        return respInstDto;
    }

}
