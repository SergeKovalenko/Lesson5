package ru.innotech.Service;

import ru.innotech.Dto.CorporateSettlementAccountDto;
import ru.innotech.Dto.ResponseAccountDto;

public interface AccountServiceable {
    void process(CorporateSettlementAccountDto reqAccDto, ResponseAccountDto respAccDto) throws Exception;
}
