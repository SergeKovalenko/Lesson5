package ru.innotech.Controllers;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.innotech.Dto.CorporateSettlementAccountDto;
import ru.innotech.Dto.ResponseAccountIntDto;
import ru.innotech.Service.AccountService;

@RestController
@Validated
@RequestMapping("/account/")
public class AccountRestConrtoller {

    @Autowired
    AccountService accountService;

    @PostMapping("/create")
    ResponseEntity<ResponseAccountIntDto> createProdRegister(@Valid @RequestBody CorporateSettlementAccountDto reqAccDto) throws Exception {
        ResponseAccountIntDto r = accountService.process(reqAccDto);
        return new ResponseEntity<>(r, HttpStatus.CREATED);
    }

}