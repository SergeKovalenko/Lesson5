package ru.innotech.Controllers;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.innotech.Dto.CorporateSettlementInstanceDto;
import ru.innotech.Dto.ResponseInstanceIntDto;
import ru.innotech.Service.InstanceService;

@RestController
@Validated
@RequestMapping("/instance/")
public class InstanceRestController {
    @Autowired
    InstanceService instanceService;

    @PostMapping("/create")
    ResponseEntity<ResponseInstanceIntDto> createInstanceRegister(@Valid @RequestBody CorporateSettlementInstanceDto ReqInstDto) throws Exception {
        ResponseInstanceIntDto r = instanceService.process(ReqInstDto);
        return new ResponseEntity<>(r, HttpStatus.CREATED);
    }
}
