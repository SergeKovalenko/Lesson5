package ru.innotech.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.innotech.Entity.TppProduct;

import java.util.List;

public interface TppProductRepo extends JpaRepository<TppProduct, String> {
    List<TppProduct> findFirstByNumber(String val);
}
