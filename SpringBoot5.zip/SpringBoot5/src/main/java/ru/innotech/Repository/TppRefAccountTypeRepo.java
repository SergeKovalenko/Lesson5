package ru.innotech.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.innotech.Entity.TppRefAccountType;

public interface TppRefAccountTypeRepo extends JpaRepository<TppRefAccountType,String> {
}
