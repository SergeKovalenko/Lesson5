package ru.innotech.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.innotech.Entity.Agreement;

import java.util.List;

public interface AgreementRepo extends JpaRepository<Agreement,String> {
    List<Agreement> findFirstByNumber(String value);
}
