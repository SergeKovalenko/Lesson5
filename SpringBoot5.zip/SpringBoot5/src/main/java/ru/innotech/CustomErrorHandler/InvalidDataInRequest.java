package ru.innotech.CustomErrorHandler;

public class InvalidDataInRequest extends RuntimeException {
    public InvalidDataInRequest(String message) {
        super(message);
    }
}
