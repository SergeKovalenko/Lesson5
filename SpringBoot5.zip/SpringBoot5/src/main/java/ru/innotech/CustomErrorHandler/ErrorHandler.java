package ru.innotech.CustomErrorHandler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import ru.innotech.Dto.ErrorDescriptionDto;

import java.util.Arrays;

@RestControllerAdvice
public class ErrorHandler {
    @ExceptionHandler(Exception.class)
    @ResponseBody
    public ResponseEntity<ErrorDescriptionDto> exceptionErrorsHandler(Exception e) {
        ErrorDescriptionDto ed = new ErrorDescriptionDto("500", e.getMessage(), Arrays.toString(e.getStackTrace()));
        return new ResponseEntity<>(ed, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(InvalidDataInRequest.class)
    @ResponseBody
    public ResponseEntity<ErrorDescriptionDto> invExceptionErrorsHandler(Exception e) {
        ErrorDescriptionDto ed = new ErrorDescriptionDto("400", e.getMessage(), Arrays.toString(e.getStackTrace()));
        return new ResponseEntity<>(ed, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(NoDataFoundException.class)
    @ResponseBody
    public ResponseEntity<ErrorDescriptionDto> NoDataFoundException(Exception e) {
        ErrorDescriptionDto ed = new ErrorDescriptionDto("404", e.getMessage(), Arrays.toString(e.getStackTrace()));
        return new ResponseEntity<>(ed, HttpStatus.NOT_FOUND);
    }
}
