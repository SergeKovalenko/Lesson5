package ru.innotech.ComponentsAccount;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import ru.innotech.CustomErrorHandler.NoDataFoundException;
import ru.innotech.Dto.Enum.Status;
import ru.innotech.Entity.*;
import ru.innotech.Dto.CorporateSettlementAccountDto;
import ru.innotech.Dto.ResponseAccountDto;
import ru.innotech.Repository.*;
import ru.innotech.Service.AccountServiceable;

import java.util.List;

@Component
@Order(3)
@Qualifier("Account")
public class AccountStep4 implements AccountServiceable {
    @Autowired
    AccountPoolRepo accountPoolRepo;
    @Autowired
    AccountRepo accountRepo;
    @Autowired
    TppProductRegisterRepo tppProductRegisterRepo;
    @Autowired
    TppRefProductRegisterTypeRepo tppRefProductRegisterTypeRepo;
    @Autowired
    TppRefAccountTypeRepo tppRefAccountTypeRepo;
    @Override
    public void process(CorporateSettlementAccountDto reqAccDto, ResponseAccountDto respAccDto){
        System.out.println("AccountStep4- Найти значение номера счета по параметрам branchCode, currencyCode, mdmCode, priorityCode, registryTypeCode из Request.Body в таблице Пулов счетов (account_pool). Номер счета берется первый из пула.");
        List<AccountPool> lAccP = accountPoolRepo.findPool(reqAccDto.getBranchCode(), reqAccDto.getCurrencyCode(), reqAccDto.getMdmCode(),reqAccDto.getPriorityCode(),reqAccDto.getRegistryTypeCode());
        if (lAccP.isEmpty()) {
            throw new NoDataFoundException("Не найден пул счетов");
        }
        List<Account> accList = accountRepo.findAccount(lAccP.get(0).getId());
        if (accList.isEmpty()) {
            throw new NoDataFoundException("Не найден свободный счет в пуле " + lAccP.get(0).getId());
        }
        Account acc = accList.get(0);
        accountRepo.save(acc);

        TppProductRegister pReg = new TppProductRegister();
        pReg.setProductId(reqAccDto.getInstanceId());
        List<TppRefProductRegisterType> lt = tppRefProductRegisterTypeRepo.findFirstByValue(reqAccDto.getRegistryTypeCode());
        pReg.setType(lt.get(0));
        pReg.setAccount(acc.getId());
        pReg.setCurrency_code(reqAccDto.getCurrencyCode());
        pReg.setState(String.valueOf(Status.OPEN));
        pReg.setAccount_number(acc.getAccount_number());
        tppProductRegisterRepo.save(pReg);

        respAccDto.setAccountId(pReg.getId().toString());


    }
}
