package ru.innotech.ComponentsAccount;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import ru.innotech.CustomErrorHandler.InvalidDataInRequest;
import ru.innotech.Service.AccountServiceable;
import ru.innotech.Dto.CorporateSettlementAccountDto;
import ru.innotech.Dto.ResponseAccountDto;
import ru.innotech.Entity.TppProductRegister;
import ru.innotech.Repository.TppProductRegisterRepo;

import java.util.List;

@Component
@Order(1)
@Qualifier("Account")
public class AccountStep2 implements AccountServiceable {
    @Autowired
    TppProductRegisterRepo tppProductRegisterRepo;
    @Override
    public void process(CorporateSettlementAccountDto reqAccDto, ResponseAccountDto respAccDto) {

        System.out.println("AccountStep2 - Проверка таблицы ПР (таблица tpp_product_register) на дубли");
        List<TppProductRegister> lr = tppProductRegisterRepo.findReg(reqAccDto.getInstanceId(), reqAccDto.getRegistryTypeCode());

      if (!lr.isEmpty()) {
            throw new InvalidDataInRequest("Параметр registryTypeCode тип регистра "+reqAccDto.getRegistryTypeCode()+" уже существует для ЭП с ИД  "+reqAccDto.getInstanceId()+".");
        }

    }
}
