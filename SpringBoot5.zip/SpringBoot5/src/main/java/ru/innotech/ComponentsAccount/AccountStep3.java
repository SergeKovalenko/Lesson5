package ru.innotech.ComponentsAccount;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import ru.innotech.CustomErrorHandler.NoDataFoundException;
import ru.innotech.Entity.TppRefProductRegisterType;
import ru.innotech.Dto.CorporateSettlementAccountDto;
import ru.innotech.Dto.ResponseAccountDto;
import ru.innotech.Repository.TppRefProductRegisterTypeRepo;
import ru.innotech.Service.AccountServiceable;

import java.util.List;
@Component
@Order(2)
@Qualifier("Account")
public class AccountStep3 implements AccountServiceable {
    @Autowired
    TppRefProductRegisterTypeRepo tppRefProductRegisterTypeRepo;
    @Override
    public void process(CorporateSettlementAccountDto reqAccDto, ResponseAccountDto respAccDto){
        System.out.println("AccountStep3- Взять значение из Request.Body.registryTypeCode и найти соответствующие ему записи в tpp_ref_product_register_type.value");
        List<TppRefProductRegisterType> lt = tppRefProductRegisterTypeRepo.findFirstByValue(reqAccDto.getRegistryTypeCode());
        if (lt.isEmpty()) {
            throw new NoDataFoundException("Код Продукта " + reqAccDto.getRegistryTypeCode()+ " не найдено в Каталоге продуктов tpp_ref_product_register_type для данного типа Регистра");
        }

    }
}
