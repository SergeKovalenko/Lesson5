import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.junit.Assert;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.web.bind.annotation.RequestBody;
import org.testcontainers.containers.PostgreSQLContainer;
import ru.innotech.Dto.CorporateSettlementInstanceDto;
import ru.innotech.Entity.*;
import ru.innotech.Repository.*;
import ru.innotech.Starter;

import java.util.Optional;

@SpringBootTest(classes = {Starter.class}, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class Tests {
    @Autowired
    AccountPoolRepo accountPoolRepo;
    @Autowired
    AccountRepo accountRepo;
    @Autowired
    AgreementRepo agreementRepo;
    @Autowired
    TppProductRegisterRepo tppProductRegisterRepo;
    @Autowired
    TppProductRepo tppProductRepo;
    @Autowired
    TppRefAccountTypeRepo tppRefAccountTypeRepo;
    @Autowired
    TppRefProductClassRepo tppRefProductClassRepo;
    @Autowired
    TppRefProductRegisterTypeRepo tppRefProductRegisterTypeRepo;

    public static PostgreSQLContainer postgreSQLContainer = new PostgreSQLContainer("postgres");

    @BeforeAll
    static void beforeAll() {
        postgreSQLContainer.start();
        RestAssured.baseURI = "http://localhost:8080";
    }

    @AfterAll
    static void afterAll() {
        postgreSQLContainer.stop();
    }

    @DynamicPropertySource
    static void confugureProperties(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", postgreSQLContainer::getJdbcUrl);
        registry.add("spring.datasource.username", postgreSQLContainer::getUsername);
        registry.add("spring.datasource.password", postgreSQLContainer::getPassword);
    }

    @Test
    void dbTestRun() {

        System.out.println("Check Database Connection");

        ApplicationContext ctx = SpringApplication.run(Starter.class);

        TppRefProductRegisterTypeRepo tppRefProductRegisterTypeRepo = ctx.getBean(TppRefProductRegisterTypeRepo.class);
        AccountPoolRepo accountPoolRepo = ctx.getBean(AccountPoolRepo.class);
        AccountRepo accountRepo = ctx.getBean(AccountRepo.class);
        TppProductRegisterRepo tppProductRegisterRepo = ctx.getBean(TppProductRegisterRepo.class);
        AgreementRepo agreementRepo = ctx.getBean(AgreementRepo.class);
        TppProductRepo tppProductRepo = ctx.getBean(TppProductRepo.class);


        AccountPool ap = new AccountPool(null, null, "001", "840", "12345", "00", "787");
        Account acc = new Account(null, ap, "40817810810100001234567");
        TppProductRegister pr = new TppProductRegister(null, 1L
                , tppRefProductRegisterTypeRepo.findById("1").get()
                , 1L, "RUB", "OPEN", "40817810810100001234567");
        TppProduct p = new TppProduct();
        Agreement a = new Agreement(null,
                p,
                "TEST1",
                "TEST2",
                "TEST3",
                null, null, null,
                null, null,
                null,
                null,
                null, null, null, null, null, null, null, null, null, null, null);

        accountPoolRepo.save(ap);
        accountRepo.save(acc);
        tppProductRegisterRepo.save(pr);
        tppProductRepo.save(p);
        agreementRepo.save(a);

        Assertions.assertEquals(agreementRepo.count(), 1);
        Assertions.assertEquals(ap.getId(), 4);
        Assertions.assertEquals(acc.getId(), 1);
        Assertions.assertEquals(a.getId(), 1);
    }

    @Test
    void webTestAccountRun() {
        ApplicationContext ctx = SpringApplication.run(Starter.class);
        String requestBody = "{\n" +
                "\t\"instanceId\":18,\n" +//изменять на следующее число, а то не пройдет проверку на дубли
                "\t\"registryTypeCode\":\"03.012.002_47533_ComSoLd\",\n" +
                "\t\"accountType\":\"Клиентский\",\n" +
                "\t\"currencyCode\":\"800\",\n" +
                "\t\"branchCode\":\"0022\",\n" +
                "\t\"priorityCode\":\"00\",\n" +
                "\t\"mdmCode\":\"15\"\n" +
                "}";

        Response response = RestAssured.given()
                .header("Content-type", "application/json")
                .and()
                .body(requestBody)
                .when()
                .post("/account/create")
                .then()
                .extract().response();
        Assertions.assertEquals(201, response.statusCode());
        //результат записывается в tpp_product_register
    }

    @Test
    void webTestInstanceRun() {
        ApplicationContext ctx = SpringApplication.run(Starter.class);
        String requestBody = "{\n" +
                "\t\"instanceId\":16,\n" + //поиск в таблице в tpp_product
                "\t\"productType\":\"НСО\",\n" +
                "\t\"productCode\":\"03.012.002\",\n" +
                "\t\"registerType\":\"03.012.002_47533_ComSoLd\",\n" +
                "\t\"mdmCode\":\"15\",\n" +
                "\t\"contractNumber\":\"013/2023_NSO_56\",\n" +//менять номер для успешного выполнения
                "\t\"contractDate\":\"2024-17-05\",\n" +
                "\t\"priority\":1,\n" +
                "\t\"interestRatePenalty\":12.3,\n" +
                "\t\"minimalBalance\":11.2,\n" +
                "\t\"thresholdAmount\":10.1,\n" +
                "\t\"accountingDetails\":\"р/с 40701810400000000001 в ПОА Банк ФК Открытие\",\n" +
                "\t\"rateType\":\"прогрессивная\",\n" +
                "\t\"taxPercentageRate\":9.9,\n" +
                "\t\"technicalOverdraftLimitAmount\":9.8,\n" +
                "\t\"contractId\":0,\n" +
                "\t\"branchCode\":\"0022\",\n" +
                "\t\"isoCurrencyCode\":\"800\",\n" +
                "\t\"urgencyCode\":\"00\",\n" +
                "\t\"referenceCode\":25,\n" +
                "\t\"additionalPropertiesVIP\":{\n" +
                "\t\t\t\"data\":[\n" +
                "\t\t\t\t\t{\"key\":\"RailwayRegionOwn\",\"value\":\"ABC\"},\n" +
                "\t\t\t\t\t{\"key\":\"counter\",\"value\":\"123\"}\n" +
                "\t\t\t]\n" +
                "\t},\n" +
                "\t\"instanceAgreements\":[\n" +
                "\t\t{\"generalAgreementId\":\"244\",\n" +
                "\t\t \"supplementaryAgreementId\":\"27\",\n" +
                "\t\t \"arrangementType\":\"СМО\",\n" +
                "\t\t \"number\":\"270\",\n" +
                "\t\t \"shedulerJobId\":\"55\",\n" +
                "\t\t \"openingDate\":\"2024-15-04\",\n" +
                "\t\t \"closingDate\":\"2024-06-06\",\n" +
                "\t\t \"cancelDate\":null,\n" +
                "\t\t \"validityDuration\":56,\n" +
                "\t\t \"cancellationReason\":null,\n" +
                "\t\t \"status\":\"открыт\",\n" +
                "\t\t \"interestCalculationDate\":\"2025-04-15\",\n" +
                "\t\t \"interestRate\":1.2,\n" +
                "\t\t \"coefficient\":1.2,\n" +
                "\t\t \"coefficientAction\":\"+\",\n" +
                "\t\t \"minimumInterestRate\":2.2,\n" +
                "\t\t \"minimumInterestRateCoefficient\":2.2,\n" +
                "\t\t \"minimumInterestRateCoefficientAction\":\"-\",\n" +
                "\t\t \"maximalInterestRate\":10,\n" +
                "\t\t \"maximalInterestRateCoefficient\":0.55,\n" +
                "\t\t \"maximalInterestRateCoefficientAction\":\"-\"\n" +
                "\t\t}\n" +
                "\t]\n" +
                "}";
        Response response = RestAssured.given()
                .header("Content-type", "application/json")
                .and()
                .body(requestBody)
                .when()
                .post("/instance/create")
                .then()
                .extract().response();
        Assertions.assertEquals(500, response.statusCode());
    }

}
